Purpose:
Currently, the workflows take a list of genes and a concept set as input, calculate the matching score between these and finds the concepts (disease or disorder) that are most similar in terms or concept profiles.

Author comments:
The workflow is in Beta stage. It runs, but needs more testing with different parameter settings. This workflow originated from pack: http://www.myexperiment.org/packs/368 for functional gene annotation and knowledge discovery.
